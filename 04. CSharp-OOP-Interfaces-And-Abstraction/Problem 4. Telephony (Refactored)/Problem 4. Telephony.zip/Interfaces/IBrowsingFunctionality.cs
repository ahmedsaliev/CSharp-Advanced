﻿using System.Collections;

namespace Telephony
{
    public interface IBrowsingFunctionality
    {
        string Browse(string site);
    }
}