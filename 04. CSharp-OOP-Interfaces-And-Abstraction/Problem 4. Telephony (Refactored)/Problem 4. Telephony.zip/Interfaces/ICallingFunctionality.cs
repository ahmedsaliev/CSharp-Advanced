﻿using System.Collections;

namespace Telephony
{
    public interface ICallingFunctionality
    {
        string Call(string contact);
    }
}