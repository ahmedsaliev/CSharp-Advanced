﻿public interface ICar
{
    string Brake();
    string PushGas();
}