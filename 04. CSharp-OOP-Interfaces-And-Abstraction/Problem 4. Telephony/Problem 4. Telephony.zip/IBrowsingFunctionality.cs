﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Problem_4._Telephony
{
    public interface IBrowsingFunctionality
    {
        string Browse();
    }
}
